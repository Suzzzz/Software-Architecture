<?php

Class Users extends CI_Model {

    //get login details
    function login($uname, $password) {
        $this->db->from('users');
        $this->db->where('username', $uname);
        $this->db->where('password',$password);

        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {

            return $query->result();
        } else {
            return false;
        }
    }

    //user activity entry



    //Save regiter User


}

?>