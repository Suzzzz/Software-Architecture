<?php

/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2016-10-02
 * Time: 11:52 AM
 */
class OrderModel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    function getOrder()
    {
        $this->db->select("orderId,customerid,customer_name,total_price,Status");
        $this->db->from('order');
        $query = $this->db->get();
        return $query->result();
    }

    function getorddet($customerid)
    {

        $this->db->select("customerid,date,foodname");
        $this->db->from('food');
        $this->db->where('customerid',$customerid);
      //  $this->db->where('date',curdate());
        $query = $this->db->get();
        return $query->result();
    }

    function updateOrder($customerid){


        $data = array(
            'Status' => "Acknowledge"
        );


        $this->db->where('customerid',$customerid);
        //$this->db->where('date',CURRENT_DATE);

        if ($this->db->update('order', $data)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

}