<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Verifylogincontroller extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('users', '', TRUE);
        $this->load->library('session');

    }

    function index() {

        $this->load->helper('url');
        $this->load->helper('form');
        //This method will have the credentials validation
        $this->load->library('form_validation');

        $this->form_validation->set_rules('txtuname', 'username', 'trim|required');
        $this->form_validation->set_rules('txtpwd', 'Password', 'trim|required');

        $pwd = $this->input->post('txtpwd');
        $uname = $this->input->post('txtuname');


        if ($this->form_validation->run() == FALSE) {
            //Field validation failed.  User redirected to login page
            $this->load->view('index');
        } else {
            if( $this->check_database($pwd,$uname)) {
                  redirect('form1Controller', 'refresh');
            } else{
             //  redirect('form1Controller', 'refresh');
        }
    }}

    function check_database($password,$uname) {
        //Field validation succeeded.  Validate against database


        //query the database
        $result = $this->users->login($uname, $password);

        if ($result) {
            //set session array
            $sess_array = array();
            foreach ($result as $row) {
                $sess_array = array(
                    'id' => $row->userId,
                    'uname' => $row->username,

                );
                //set session
                $this->session->set_userdata('logged_in', $sess_array);
            }
            
            //set session dates
            $sess_dates = array(
                'start_date' => date("Y-m-1", strtotime("-6 months")),
                'end_date' => date("Y-m-d")
            );
            $this->session->set_userdata('dashboard_dates', $sess_dates);
            return TRUE;
            
        } else {
            $this->form_validation->set_message('check_database', 'Invalid Password');
            return false;
        }
    }

}

?>