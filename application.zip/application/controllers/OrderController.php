<?php

/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2016-10-02
 * Time: 11:50 AM
 */
class OrderController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('url_helper');
        $this->load->database();
        $this->load->model('OrderModel');
        $this->load->library('session');
        $this->load->helper('form_helper');
    }

    public function index()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');

        $this->data['posts'] = $this->OrderModel->getOrder();
        $this->load->view('form1', $this->data);

    }

    function delete_Task($id)
    {

        $this->db->where('orderId ', $id);
        $this->db->delete('order');
        redirect('OrderController/index');
    }



}