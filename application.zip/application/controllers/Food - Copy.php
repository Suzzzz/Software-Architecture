<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 
class Food extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Food_model');
    } 

    /*
     * Listing of food
     */
    function index()
    {
		$this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->helper('url');
        $data['food'] = $this->Food_model->get_all_food();

        $this->load->view('food/index',$data);
    }

    /*
     * Adding a new food
     */
    function add()
    {   $this->load->helper('form');
        
		$this->load->helper('url');
        $this->load->library('form_validation');

		$this->form_validation->set_rules('foodname','Foodname','required');
		$this->form_validation->set_rules('foodprice','Foodprice','required|greater_than[0]');
		$this->form_validation->set_rules('category','Category','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'foodname' => $this->input->post('foodname'),
				'foodprice' => $this->input->post('foodprice'),
				'category' => $this->input->post('category'),
            );
            
            $food_id = $this->Food_model->add_food($params);
            redirect('food/index');
        }
        else
        {
            $this->load->view('food/add');
        }
    }  

    /*
     * Editing a food
     */
    function edit($foodid)
    {   
	    $this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->helper('url');
        // check if the food exists before trying to edit it
        $food = $this->Food_model->get_food($foodid);
        
        if(isset($food['foodid']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('foodname','Foodname','required');
			$this->form_validation->set_rules('foodprice','Foodprice','required|greater_than[0]');
			$this->form_validation->set_rules('category','Category','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'foodname' => $this->input->post('foodname'),
					'foodprice' => $this->input->post('foodprice'),
					'category' => $this->input->post('category'),
                );

                $this->Food_model->update_food($foodid,$params);            
                redirect('food/index');
            }
            else
            {   
                $data['food'] = $this->Food_model->get_food($foodid);
    
                $this->load->view('food/edit',$data);
            }
        }
        else
            show_error('The food you are trying to edit does not exist.');
    } 

    /*
     * Deleting food
     */
    function remove($foodid)
    {
		$this->load->helper('form');
        $this->load->library('form_validation');
		$this->load->helper('url');
        $food = $this->Food_model->get_food($foodid);

        // check if the food exists before trying to delete it
        if(isset($food['foodid']))
        {
            $this->Food_model->delete_food($foodid);
            redirect('food/index');
        }
        else
            show_error('The food you are trying to delete does not exist.');
    }
    
}
