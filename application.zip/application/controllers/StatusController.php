<?php

/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 2016-10-02
 * Time: 12:53 PM
 */
class StatusController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('url_helper');
        $this->load->database();
        $this->load->model('OrderModel');
        $this->load->library('session');
        $this->load->helper('form_helper');
    }

    public function index($custID)
    {
        $this->load->helper('form');
        $this->load->library('form_validation');

       if($this->OrderModel->updateOrder($custID))
       {$data['posts'] = $this->OrderModel->getOrddet($custID);
        $this->load->view('Status',$data);}

    }

}