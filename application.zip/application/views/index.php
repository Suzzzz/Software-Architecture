<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>OpsSNDash | Log in</title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="shortcut icon" type="image/png" href="<?php echo base_url('public/dist/img/pearson-logo.png'); ?>" />
        <!-- Bootstrap 3.3.5 -->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('public/bootstrap/css/bootstrap.min.css'); ?>">
        <!-- Bootstrap Switch -->
        <link rel="stylesheet" href="<?php echo base_url('public/dist/css/bootstrap-switch.css'); ?>">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo base_url('public/plugins/datatables/dataTables.bootstrap.css'); ?>">
        <!-- daterange picker -->
        <link rel="stylesheet" href="<?php echo base_url('public/plugins/daterangepicker/daterangepicker-bs3.css'); ?>">
        <!-- iCheck for checkboxes and radio inputs -->
        <link rel="stylesheet" href="<?php echo base_url('public/plugins/iCheck/all.css'); ?>">
        <!-- Bootstrap Color Picker -->
        <link rel="stylesheet" href="<?php echo base_url('public/plugins/colorpicker/bootstrap-colorpicker.min.css'); ?>">
        <!-- Bootstrap time Picker -->
        <link rel="stylesheet" href="<?php echo base_url('public/plugins/timepicker/bootstrap-timepicker.min.css'); ?>">
        <!-- Select2 -->
        <link rel="stylesheet" href="<?php echo base_url('public/plugins/select2/select2.min.css'); ?>">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo base_url('public/dist/css/AdminLTE.min.css'); ?>">
        <!-- DataTables File Export -->
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="<?php echo base_url('public/dist/css/skins/_all-skins.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo base_url('public/dist/css/animate.css'); ?>">
        <!--Toggle -->
        <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.0/css/bootstrap-toggle.min.css" rel="stylesheet">
        <!-- Morphext -->
        <link rel="stylesheet" href="<?php echo base_url('public/dist/css/morphext.css'); ?>">
        <!-- HoldOn -->
        <link rel="stylesheet" href="<?php echo base_url('public/dist/css/HoldOn.css'); ?>">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition login-page">

        <div class="login-box">
            <div class="login-logo">
                <a href="#"><b>SLIIT</b> Canteen </a>
            </div><!-- /.login-logo -->
            <div class="login-box-body">
                <p class="login-box-msg">Sign in to start your session</p>
                <?php echo validation_errors(); ?>
                <?php echo form_open('Verifylogincontroller'); ?>
                <div class="form-group has-feedback">
                    <input id="username" type="username" class="form-control" placeholder="User Name" name="txtuname">
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input id="password" type="password" class="form-control" placeholder="Password" name="txtpwd">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="row">
                    <div class="col-xs-8">
                        <div class="checkbox icheck>
                            <label>
                                <input id="rememberMe" type="checkbox" >
                            </label>
                        </div>
                    </div><!-- /.col -->
                    <div class="col-xs-4">
                        <button id="submitlogin" type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                    </div><!-- /.col -->
                </div>




            </div><!-- /.login-box-body -->
           </div>
        
         
</div>
        
        <!-- /.login-box -->
           <!-- jQuery 2.1.4 -->
        <script src="<?php echo base_url('public/plugins/jQuery/jQuery-2.1.4.min.js'); ?>"></script>
        <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
        <script src="<?php echo base_url('public/dist/js/jquery.noty.packaged.js?v=1'); ?>"></script>
        <!-- Bootstrap 3.3.5 -->
        <script src="<?php echo base_url('public/bootstrap/js/bootstrap.min.js'); ?>"></script>
        <!-- jQuery UI 1.11.4 -->
         <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js?v=1"></script>
         <!-- Morphext -->
        <script src="<?php echo base_url('public/dist/js/jquery.animatecss.js?v=1'); ?>"></script>
        <!-- HoldOn -->
             <script src="<?php echo base_url('public/dist/js/HoldOn.js?v=1'); ?>"></script>
        <!-- Select2 -->
       <script src="<?php echo base_url('public/plugins/select2/select2.full.min.js?v=1'); ?>"></script>
        <!-- AdminLTE App -->
       <script src="<?php echo base_url('public/dist/js/app.min.js?v=1'); ?>"></script>
      <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url('public/dist/js/demo.js?v=1'); ?>"></script>

        <!-- iCheck -->
        <script src="<?php echo base_url('public/plugins/iCheck/icheck.min.js'); ?>"></script>
        <script src="<?php echo base_url('public/dist/js/scripts/globalList.js?v=1'); ?>"></script>
        <script src="<?php echo base_url('public/dist/js/scripts/commonFunctions.js?v=1'); ?>"></script>
        <script src="<?php echo base_url('public/dist/js/scripts/showSystemDownAlert.js?v=1'); ?>"></script>
     
        
        
        
        <script>
    
//     $(function () {
//        $.ajaxSetup({
//            cache: true
//        });}
    
//    localSettings.SetNotification ="True";
    $('#div_show_alert').hide();
    
    $(function () {
                if (localStorage.checkBoxValidation && localStorage.checkBoxValidation !== '') {
                    $('#rememberMe').attr('checked', true);
                    $('#loginEmail').val(localStorage.userName);
                    $('#password').val(localStorage.password);
                } else {
                    $('#rememberMe').attr('checked', false);
                    $('#loginEmail').val('');
                    $('#password').val('');
                }

                $('input').iCheck({
                    checkboxClass: 'icheckbox_square-blue',
                    radioClass: 'iradio_square-blue',
                    increaseArea: '20%' // optional
                });

            });

            $('#submitlogin').click(function () {

                if ($('#rememberMe').is(':checked')) {
                    // save username and password
                    localStorage.userName = $('#loginEmail').val();
                    localStorage.password = $('#password').val();
                    localStorage.checkBoxValidation = $('#rememberMe').val();
                } else {
                    localStorage.userName = '';
                    localStorage.password = '';
                    localStorage.checkBoxValidation = '';
                }
            });
            
      
   var status = '<?php echo $status_detail['status'] ?>';
   var stime =  '<?php echo $status_detail['start_time'] ?>';
   var etime =  '<?php echo $status_detail['end_time'] ?>';
      if(status == 'Enable')
  {      
      $('#div_show_alert').show();
    
    
    } 
   
    
            
            
       

        </script>
    </body>
</html>
